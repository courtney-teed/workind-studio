$(document).ready(function(){
    $('#container').fadeIn();
});
